# Tutorial — CI/CD Workflow with DeployKit

## Objective
Automate build, test, and deploy for a web service to staging.

## Pipeline Stages
1. **Trigger:** On pull request to `main`.
2. **Build:** Install dependencies; compile assets.
3. **Test:** Run unit and integration tests with coverage.
4. **Package:** Create Docker image; tag with commit SHA.
5. **Deploy:** Push to registry; deploy to staging cluster.

## Success Criteria
- All checks green; deployment URL available.
