# Tutorial — Send a Voice Note (Mobile Beginner)

## Objective
Record and send a 30‑second voice note in a channel.

## Steps
1. Open a channel → tap **Mic**.
2. Press‑and‑hold to record (max 30s).
3. Release to preview; tap **Play** to review.
4. Add a caption (optional) → **Send**.

## Tips
- Use a quiet environment; keep the phone 15–20 cm from mouth.
- Delete and re‑record if background noise is high.
