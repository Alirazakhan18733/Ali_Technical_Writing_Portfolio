# Test Plan — CollabSpace v1.x

## Scope
- Functional testing for channels, messages, files.
- Non‑functional: performance, accessibility, security basics.

## Approach
- Risk‑based prioritization.
- Mix of manual and automated tests.

## Environments
- Staging (`stg`) and Production (`prod`) with feature flags.

## Entry/Exit Criteria
- **Entry:** Code complete; unit tests ≥ 80% coverage.
- **Exit:** P1 bugs resolved; regression suite green.

## Deliverables
- Test cases, run results, defect reports, summary sign‑off.
