# Test Cases — Samples

| ID | Title | Steps | Expected |
|---|---|---|---|
| TC‑001 | Create channel | 1) Sign in 2) Create channel | Channel listed; owner assigned |
| TC‑002 | Post message | 1) Open channel 2) Send message | Message visible; timestamp shown |
| TC‑003 | Upload file > limit | 1) Upload 300 MB file | Error shown: File exceeds 250 MB |
| TC‑004 | Thread reply | 1) Reply to message | Reply nested; notification sent |
