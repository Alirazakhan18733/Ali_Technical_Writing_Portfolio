# Automation Flow Summary

## Objective
Continuously validate core workflows on pull requests and nightly builds.

## Flow
1. **Trigger:** PR to `main` and nightly schedule (`cron`).
2. **Static Checks:** Lint, type checks, secrets scan.
3. **Unit Tests:** Parallel matrix across Node 18/20.
4. **Integration Tests:** Spin up services via Docker Compose; run API tests (Newman/Postman).
5. **E2E:** Headless UI tests (Playwright) against ephemeral environment.
6. **Artifacts:** Upload logs, coverage, screenshots, videos.
7. **Gates:** Require all checks green before merge to `main`.
8. **Reporting:** Post summary comment with pass rate; create defects for failures.

## Metrics
- Build time, pass rate, flaky tests, coverage delta, mean time to repair (MTTR).

## Notes
- Secrets handled via CI provider; least‑privilege tokens.
- Tests isolated; data seeded and cleaned per run.
