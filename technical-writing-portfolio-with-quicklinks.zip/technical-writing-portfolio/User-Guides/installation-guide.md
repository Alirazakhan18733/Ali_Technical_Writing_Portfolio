# Installation Guide — CollabSpace (Mobile & Web)

> Target platforms: iOS, Android, modern web browsers (Chromium, Firefox, Safari).

## Prerequisites
- Corporate email or verified account.
- Stable internet connection.
- iOS 15+, Android 11+, latest two versions of Chrome/Edge/Firefox/Safari.

## Mobile (iOS)
1. Open the **App Store** and search for **CollabSpace**.
2. Tap **Get** → **Install**.
3. Launch the app and select **Sign in with Company**.
4. Enter your email, then approve the MFA prompt.
5. (Optional) Allow notifications for mentions and meeting alerts.

## Mobile (Android)
1. Open **Google Play** and search **CollabSpace**.
2. Tap **Install**.
3. Open the app → **Sign in with Company**.
4. Complete MFA. Set a device screen lock if prompted.

## Web (Desktop)
1. Navigate to `https://app.collabspace.example.com`.
2. Sign in with your corporate account.
3. To install as a PWA: **More (⋮)** → **Install App**.

## Post‑Install Checklist
- [ ] Profile updated (name, photo, timezone).
- [ ] Teams and channels joined.
- [ ] Notifications configured.
- [ ] Mobile and web sessions verified.

## Uninstall
- **iOS/Android:** Long‑press → **Remove App**.
- **Web PWA:** Browser **Settings** → **Manage apps** → **Uninstall**.
