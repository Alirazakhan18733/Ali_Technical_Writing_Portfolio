# Feature Walkthrough — Chat & Channels (Teams‑like)

## Overview
Real‑time messaging with threads, mentions, file sharing, and presence.

## Key Concepts
- **Teams:** Workspaces grouping channels and permissions.
- **Channels:** Topic‑based message streams.
- **Threads:** Replies anchored to a root message.
- **Mentions:** `@user` and `@team` notifications.
- **Files:** In‑line previews with version history.

## Walkthrough
1. **Create Team** → **Create** → name, description, visibility.
2. **Create Channel** → pick **Standard** or **Private**.
3. **Post** → format with bold, code, and lists.
4. **Reply in Thread** to retain context; avoid cross‑posting.
5. **Share Files** → drag‑and‑drop; use **Version** to compare changes.
6. **Moderation** → channel owners can archive, mute, or limit reactions.
7. **Notifications** → tune per‑channel (All, Mentions, None).

## Best Practices
- Prefer threads for decisions. Summarize outcomes.
- Use concise titles. Avoid redundant @mentions.
- Archive inactive channels quarterly.
