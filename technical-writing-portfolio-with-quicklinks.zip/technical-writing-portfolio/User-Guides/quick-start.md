# Quick Start — CollabSpace

## Goal
Send your first message, mention a teammate, and share a file in under 5 minutes.

## Steps
1. **Create or Join a Team** → **Create team** or accept an invite.
2. **Open a Channel** (e.g., `#general`).
3. **Post a Message** → type text → **Send**.
4. **Mention** a teammate using `@name`.
5. **Attach a File** → **+** → **Upload** (PDF, DOCX, PNG, etc.).
6. **Reply in Thread** to keep context.
7. **Set Notifications** → **Settings → Notifications**.

## Tips
- Use **slash commands** (e.g., `/schedule`) for quick actions.
- Pin critical messages to the channel header.
- Use **Search (Ctrl/Cmd+K)** to jump between items.
