# Troubleshooting Guide — CollabSpace

## Common Issues
| Symptom | Likely Cause | Resolution |
|---|---|---|
| Cannot sign in | Incorrect SSO domain | Verify email domain; clear cache; retry SSO. |
| Missing notifications | OS‑level focus mode | Allow app notifications; check channel settings. |
| Upload fails | File > 250 MB | Compress file or use shared drive link. |
| Messages unsent | Network instability | Switch networks; retry; enable offline drafts. |
| Mobile crash | Outdated build | Update app; collect logs if issue persists. |

## Collecting Logs
- **Mobile:** Settings → **Help & Feedback** → **Send diagnostics**.
- **Web:** Open DevTools → **Console** → export.

## Escalation
1. Capture screenshots and timestamps.
2. Include steps to reproduce and expected vs actual behavior.
3. Send to Support with app version and platform details.
