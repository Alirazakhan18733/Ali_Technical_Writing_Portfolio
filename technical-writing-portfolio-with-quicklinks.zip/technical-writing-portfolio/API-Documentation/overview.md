# REST API Overview — CollabSpace Platform API v1

Base URL: `https://api.collabspace.example.com/v1`

## Principles
- Resource‑oriented URIs, predictable HTTP verbs.
- JSON request/response with UTF‑8 encoding.
- Standard HTTP status codes; errors include machine‑readable codes.
- Pagination via `limit`, `cursor`.

## Versioning
- URI versioning (`/v1`).
- Backward‑compatible changes only in minor releases.

## Rate Limits
- Default: 1000 requests / minute / token.
- Exceeding returns `429 Too Many Requests` with `Retry‑After`.

## SDKs
- REST only (sampled). Use OpenAPI description to generate clients.
