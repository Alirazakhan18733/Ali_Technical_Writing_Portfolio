# Authentication

## Method
- **OAuth 2.0** with confidential or public clients.
- Send access tokens as `Authorization: Bearer {token}`.

## Token Endpoints
- `POST /oauth/token` — exchange auth code for access token.
- `POST /oauth/token/refresh` — refresh an expiring token.

## Scopes
| Scope | Grants |
|---|---|
| `channels:read` | Read channels and membership. |
| `messages:write` | Create messages and replies. |
| `files:read` | Read file metadata and download links. |
| `admin:users` | Manage users (restricted). |

## Errors
- `401 Unauthorized` when token is invalid or expired.
- `403 Forbidden` when scope is insufficient.
