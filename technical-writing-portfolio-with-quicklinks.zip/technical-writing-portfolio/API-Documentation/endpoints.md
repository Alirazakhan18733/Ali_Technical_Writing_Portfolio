# Endpoints

## Channels
- `GET /channels` — List channels (paginated).
- `POST /channels` — Create a channel.
- `GET /channels/{id}` — Get channel details.
- `PUT /channels/{id}` — Update channel metadata.
- `DELETE /channels/{id}` — Archive a channel.

## Messages
- `GET /channels/{id}/messages` — List messages.
- `POST /channels/{id}/messages` — Create a message.
- `POST /messages/{id}/replies` — Reply in thread.

## Files
- `POST /files` — Upload (multipart).
- `GET /files/{id}` — Get metadata.
- `DELETE /files/{id}` — Delete (soft‑delete).

## Users
- `GET /users/me` — Current user.
- `GET /users/{id}` — User profile.
