# Request & Response Examples

## Create Channel
**Request**
```http
POST /v1/channels HTTP/1.1
Host: api.collabspace.example.com
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "product-announcements",
  "visibility": "standard",
  "description": "Official product updates"
}
```

**Response** `201 Created`
```json
{
  "id": "chn_9fA12",
  "name": "product-announcements",
  "visibility": "standard",
  "created_at": "2026-01-15T09:20:11Z"
}
```

## Post Message
**Request**
```http
POST /v1/channels/chn_9fA12/messages HTTP/1.1
Authorization: Bearer <token>
Content-Type: application/json

{
  "text": "Welcome to the channel!",
  "mentions": ["usr_72k"]
}
```

**Response** `201 Created`
```json
{
  "id": "msg_42de",
  "channel_id": "chn_9fA12",
  "text": "Welcome to the channel!",
  "mentions": ["usr_72k"],
  "created_at": "2026-01-15T09:21:02Z"
}
```

## List Messages (Paginated)
```http
GET /v1/channels/chn_9fA12/messages?limit=50&cursor=eyJwYWdlIjoyfQ== HTTP/1.1
Authorization: Bearer <token>
```

**Response** `200 OK`
```json
{
  "items": [ { "id": "msg_42de", "text": "Welcome to the channel!" } ],
  "next_cursor": null
}
```
