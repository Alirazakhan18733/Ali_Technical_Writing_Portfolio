# Error Codes & Responses

| HTTP | Code | Message | When |
|---|---:|---|---|
| 400 | `invalid_request` | Request malformed | Missing required field |
| 401 | `invalid_token` | Token invalid/expired | Missing/expired bearer token |
| 403 | `insufficient_scope` | Scope missing | Action not allowed by scope |
| 404 | `not_found` | Resource not found | ID does not exist |
| 409 | `conflict` | State conflict | Duplicate name or version |
| 413 | `payload_too_large` | File too large | Upload exceeds limit |
| 429 | `rate_limited` | Too many requests | Throttling in effect |
| 500 | `server_error` | Unexpected error | Transient backend failure |

**Error Envelope**
```json
{
  "error": {
    "code": "invalid_request",
    "message": "Missing field: name",
    "correlation_id": "c0a8017e-7b1e-41de-a4e2-8f9b0fa2b814"
  }
}
```
