# Templates

## Documentation Template
```md
# Title

## Overview
Short summary.

## Prerequisites
- Item 1

## Steps
1. Step one
2. Step two

## Validation
How to confirm success.

## Troubleshooting
Known issues and fixes.
```

## Issue Template (GitHub)
```md
**Summary**
A clear, concise description.

**Steps to Reproduce**
1. Go to '...'
2. Click on '...'

**Expected**

**Actual**

**Environment**
- App version:
- OS:

**Attachments**
Screenshots or logs.
```
