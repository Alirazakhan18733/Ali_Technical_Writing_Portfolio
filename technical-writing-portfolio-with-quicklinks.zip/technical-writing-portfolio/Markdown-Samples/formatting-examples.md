# Markdown Formatting — Samples

## Headings
- Use `#` → `####` to structure topics logically.

## Tables
| Column | Meaning |
|---|---|
| `id` | Unique identifier |
| `created_at` | ISO‑8601 timestamp |

## Images
```md
![Channel screenshot](docs/images/channel.png)
```

## Code Blocks
```bash
curl -H "Authorization: Bearer <token>"   https://api.collabspace.example.com/v1/channels
```

```json
{
  "id": "chn_123",
  "name": "general"
}
```

## Callouts
> **Note:** Threads keep discussions organized.
