# Data Flow Explanation

1. Client authenticates with IdP and receives an access token.
2. Client calls REST endpoints with `Authorization: Bearer` header.
3. API gateway validates token, routes request to services.
4. Services query/update the database and publish events.
5. WebSocket gateway pushes events (e.g., new messages) to subscribers.
6. Files upload to object storage; metadata recorded in DB.
7. Observability pipeline aggregates logs/metrics for alerting.
