# Architecture Overview — CollabSpace

## High‑Level
- **Client:** Web SPA (React) + native iOS/Android.
- **Edge:** CDN + TLS termination.
- **API Layer:** REST services, stateless, horizontally scalable.
- **Messaging:** Real‑time gateway (WebSocket) with pub/sub.
- **Data:** Relational DB for core entities; object storage for files.
- **Identity:** OAuth 2.0 / OIDC with MFA.
- **Observability:** Centralized logs, metrics, tracing.

## Diagram (Mermaid)
```mermaid
flowchart LR
  Client[Web & Mobile Apps] --> Edge[CDN / WAF]
  Edge --> API[REST API]
  Edge --> WS[WebSocket Gateway]
  API --> Svc[Microservices]
  WS --> Svc
  Svc --> DB[(Relational DB)]
  Svc --> Obj[(Object Storage)]
  Svc --> IdP[Identity Provider]
```
