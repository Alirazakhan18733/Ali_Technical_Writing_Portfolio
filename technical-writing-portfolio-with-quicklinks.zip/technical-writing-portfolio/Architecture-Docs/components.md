# Component Overview

| Component | Purpose | Tech (example) |
|---|---|---|
| Web Client | User interface | React, TypeScript |
| Mobile Apps | Native capabilities | Swift, Kotlin |
| API Gateway | Routing, auth, rate limiting | NGINX / Envoy |
| Services | Business logic | Node.js / Java |
| Real‑time Gateway | Bi‑directional messaging | WebSocket |
| Database | Durable storage | PostgreSQL |
| Object Storage | Files and media | S3‑compatible |
| Identity | Auth, tokens, SSO | OIDC |
| CI/CD | Build, test, deploy | GitHub Actions |
