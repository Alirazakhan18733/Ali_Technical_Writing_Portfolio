# Editing Samples — Before & After

## Example 1 — Clarity
**Before:**
> Users are recommended to consider the possibility of experiencing intermittent issues if the network conditions happen to be unstable.

**After:**
> Messages may fail on unstable networks. Retry or switch networks.

**Change Rationale:** Remove hedging, reduce complexity, front‑load action.

## Example 2 — Tone
**Before:**
> You did not configure notifications correctly.

**After:**
> Notifications are off for this channel. Turn them on in Settings → Notifications.

**Change Rationale:** Neutral, user‑centered language with a clear fix.

## Example 3 — Structure
**Before:** One long paragraph with multiple steps.

**After:** Numbered steps with one action per line; bold UI labels.
