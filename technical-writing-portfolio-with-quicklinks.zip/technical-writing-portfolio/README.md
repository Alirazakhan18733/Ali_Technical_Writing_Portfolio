# Technical Writing Portfolio — Ali Shrafat Raza

> Concise, enterprise‑grade documentation across mobile, collaboration, API, CI/CD, testing, and cloud software domains. All examples are fictional and created for demonstration.

## Purpose
This repository showcases my technical writing capabilities through structured, standards‑aligned documentation samples. The portfolio demonstrates clear information architecture, accurate terminology, and consistent style.

## Role
**Author:** Ali Shrafat Raza — Associate Technical Writer  
**Scope:** End‑user guides, API docs, tutorials, release notes, architecture summaries, UX microcopy, editing samples, markdown patterns, and testing artifacts.

## Contents
- **/User-Guides** — Install, quick start, feature walkthrough, troubleshooting.
- **/API-Documentation** — REST overview, auth, endpoints, examples, errors.
- **/Release-Notes** — Versioned notes with What’s New, Enhancements, Fixes.
- **/Tutorials** — Mobile feature, CI/CD workflow, GitHub Actions example.
- **/Architecture-Docs** — High‑level architecture, components, data flow.
- **/UX-Content** — UI labels, empty states, error style guide.
- **/Case-Studies** — Problem → solution narrative with outcomes.
- **/Editing-Samples** — Before/after edits with rationale.
- **/Markdown-Samples** — Tables, code, images, templates.
- **/Testing-Docs** — Test plan, test cases, automation overview.

## Tools & Methods
- **Docs:** Markdown, Git, GitHub.
- **APIs:** OpenAPI concepts, cURL, Postman‑style examples, JSON schemas.
- **CI/CD:** GitHub Actions, semantic versioning, changelog discipline.
- **Design & Architecture:** Mermaid diagrams (Markdown), component mapping.
- **Quality:** Style guides, terminology management, standards compliance.

## About Me
I am an **Associate Technical Writer** with experience across mobile apps, collaboration platforms, CI/CD workflows, REST APIs, automation/testing, and cloud software. I focus on:
- delivering concise, user‑centered guides,
- standardizing API reference patterns with stable IA,
- tightening review cycles via CI linting and templates, and
- ensuring consistency across UX copy and release communications.

**Strengths:** Structured thinking, versioned docs, cross‑functional collaboration, and calm, action‑oriented tone.

## Hiring Manager Quick Links
- **User Onboarding (Quick Start):** [`/User-Guides/quick-start.md`](User-Guides/quick-start.md)
- **Chat Feature Walkthrough:** [`/User-Guides/feature-walkthrough-chat.md`](User-Guides/feature-walkthrough-chat.md)
- **API Overview:** [`/API-Documentation/overview.md`](API-Documentation/overview.md)
- **Auth & Examples:** [`/API-Documentation/authentication.md`](API-Documentation/authentication.md), [`examples`](API-Documentation/examples.md)
- **Release Notes Sample:** [`/Release-Notes/v1.1.md`](Release-Notes/v1.1.md)
- **Architecture Overview:** [`/Architecture-Docs/architecture-overview.md`](Architecture-Docs/architecture-overview.md)
- **Editing Samples:** [`/Editing-Samples/before-after-01.md`](Editing-Samples/before-after-01.md)
- **Testing Plan:** [`/Testing-Docs/test-plan.md`](Testing-Docs/test-plan.md)

## How to Navigate (for Recruiters)
1. Start with **/User-Guides/quick-start.md** for tone and clarity.
2. Review **/API-Documentation/** for technical depth and structure.
3. Scan **/Release-Notes/** to see product iteration style.
4. Check **/Tutorials/** for procedural accuracy and code snippets.
5. Glance at **/Architecture-Docs/** for systems understanding.
6. See **/UX-Content/** and **/Editing-Samples/** for microcopy and editing.

> All product names (e.g., *CollabSpace*, *DeployKit*) and data are fictional.
