# UI Labels & Microcopy Samples

| UI Element | Text | Guidance |
|---|---|---|
| Primary button | **Send** | Use verbs; max 1–2 words. |
| Secondary action | **Cancel** | Provide safe exit. |
| Search placeholder | *Search messages and files* | Describe scope. |
| Empty channel title | **Start the conversation** | Encourage action. |
| Tooltip | *Mentions notify teammates* | Clarify feature value. |
