# Error Message Style Guide

## Structure
- **Title:** Short and specific.
- **Explanation:** One sentence, actionable.
- **Resolution:** Primary action first.

## Examples
- **Title:** Cannot upload file
  - **Explanation:** The file exceeds the 250 MB limit.
  - **Resolution:** Compress the file or share a link.
- **Title:** Session expired
  - **Explanation:** For your security, please sign in again.
  - **Resolution:** **Sign in**

## Tone
- Neutral, clear, non‑blaming. Avoid jargon. Avoid exclamation marks.
