# Empty State Messages

## New Workspace
- **Title:** Welcome to CollabSpace
- **Body:** Create your first team to collaborate in channels.
- **CTA:** **Create team**

## No Search Results
- **Title:** No results
- **Body:** Try different keywords or filters.
- **CTA:** **Clear filters**

## No Notifications
- **Title:** You’re all caught up
- **Body:** New mentions and replies will appear here.
- **CTA:** *(none)*
